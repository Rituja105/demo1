<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Succesful</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>
  <body>
   
    
  <div class="alert alert-success" role="alert">
  <b> Registered Succesfully!<b>
</div>




<hr>
<div class="p-3 mb-2 bg-danger text-white"> <big> <b> <h2>All Blood Bank Centre's In Amravati <h2> <b> <big> </div>
 
<hr> 

<div class="container">
    <div class="row">
    <div class="col-sm-4">
  <div class="card" style="width: 18rem;">
  <img src="bb.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Balaji Blood Bank & Component Lab
        <br>Contact: 9823045532
    </h5>

    <p class="card-text">Address: Near Janmadhyam Press, Amba Peth, Amravati, Maharashtra 444601.
       
    </p>
    
    <a href="ttt.png" class="btn btn-primary">Direction</a>
  </div>
</div>
</div>
<div class="col-sm-4">
  <div class="card" style="width: 18rem;">
  <img src="bb.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">District General Hospital Blood Bank
        <br>  Contact: 7212663339
    </h5>
    <p class="card-text">Address: Khaparde Bagicha, Maltekdi, Amravati, Maharashtra 444606.</p>
    <a href="ir.png" class="btn btn-primary">Direction</a>
  </div>
</div>
</div>
<div class="col-sm-4">
  <div class="card" style="width: 18rem;">
  <img src="bb.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Sant Gadge Baba Blood Bank
        <br>  Contact: 7212580490
    </h5>
    <p class="card-text">Address: Old town, Badnera, Amravati, Maharashtra <br>444607.</p>
    <a href="sg.png" class="btn btn-primary">Direction</a>
  </div>
</div>
</div>
</div>
</div>
<br>
<br>

<div class="container">
    <div class="row">
    <div class="col-sm-4">
  <div class="card" style="width: 18rem;">
  <img src="bb.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">PDMMC BLOOD <br> BANK
<br>  Contact: 7212665545
</h5>
    <p class="card-text">Kanta Nagar, Amravati, Maharashtra  444603.</p>
    <a href="pdmc.png" class="btn btn-primary">Direction</a>
  </div>
</div>
</div>
<div class="col-sm-4">
  <div class="card" style="width: 18rem;">
  <img src="bb.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Blood Donation <br> Center
<br>  Contact: 8459331200</h5>
    <p class="card-text">Nai Basti, Amravati, Maharashtra <br> 444607.</p>
    <a href="bdc.png" class="btn btn-primary">Direction</a>
  </div>
</div>
</div>
<div class="col-sm-4">
  <div class="card" style="width: 18rem;">
  <img src="bb.jpg" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Blood Care Computerised Clinical Lab
        <br>  Contact: 9637963860
</h5>
    <p class="card-text">Walgaon Road, Amravati, Maharashtra 444601.</p>
    <a href="bcc.png" class="btn btn-primary">Direction</a>
  </div>
</div>
</div>
</div>
</div>

<br>

<div class="d-grid gap-2">
  <a class="btn btn-danger"  href="home.php" role="button"><b>Back To HomePage</b></a>
  
</div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>