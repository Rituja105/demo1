

<html>

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  
</head>

<body>

<div class="p-3 mb-2 bg-danger text-white"> <b> <h2>Need Blood Registration Form<h2> <b>  </div>
 

<div id="page-container" style="margin-top:50px; position: relative;min-height: 84vh;">
  <div class="container">
  <div id="content-wrap" style="padding-bottom:50px;">
<div class="row">
    <div class="col-lg-6">
      
      </div>
</div>



<form name="need" action="tanveer.php" method="post">
<div class="row">
<div class="col-lg-4 mb-4">
<div class="font-italic">Full Name<span style="color:red">*</span></div>
<div><input type="text" name="fname" class="form-control" required></div>
</div>
<div class="col-lg-4 mb-4">
<div class="font-italic">Mobile Number<span style="color:red">*</span></div>
<div><input type="text" name="mno" class="form-control" required></div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Gender<span style="color:red">*</span></div>
<div><select name="gen" class="form-control" required>
<option value="">Select</option>
<option value="Male">Male</option>
<option value="Female">Female</option>
</select>
</div>
</div>

</div>


<div class="row">

<div class="col-lg-4 mb-4">
<div class="font-italic">Blood Group<span style="color:red">*</span></div>
<div><select name="blood" class="form-control" required>
<option value="">Select</option>
<option value="A+">A+</option>
<option value="A-">A-</option>
<option value="B+">B+</option>
<option value="B-">B-</option>
<option value="AB+">AB+</option>
<option value="AB-">AB-</option>
<option value="O+">O+</option>
<option value="O-">O-</option>
</select>
</div>
</div>

<div class="col-lg-4 mb-4">
<div class="font-italic">Blood Centres<span style="color:red">*</span></div>
<div><select name="centre" class="form-control" required>
<option value="">Select</option>
<option value="Balaji Blood Bank & Component Lab">Balaji Blood Bank & Component Lab</option>
<option value="District General Hospital Blood Bank">District General Hospital Blood Bank</option>
<option value="Sant Gadge Baba Blood Bank">Sant Gadge Baba Blood Bank</option>
<option value="PDMMC BLOOD
BANK">PDMMC BLOOD
BANK</option>
<option value="Blood Donation
Center">Blood Donation
Center</option>
<option value="Blood Care Computerised Clinical Lab">Blood Care Computerised Clinical Lab</option>
</select>
</div>
</div>


<div class="col-lg-4 mb-4">
<div class="font-italic">Blood Amount..*1 unit = 1 bag*<span style="color:red">*</span></div>
<div><input type="text" name="amt" class="form-control" required></div>
</div>

</div>





  <div><input type="submit" name="submit" class="btn btn-primary" value="Submit" style="cursor:pointer"> </div>
  
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  <br>
  
  <div class="d-grid gap-2">
  <a class="btn btn-danger"  href="home.php" role="button"><b>Back To HomePage</b></a>
  
</div>
  

  </div>
</div>
</div>
</div>

<?php include('footer.php') ?>
</div>
</body>
</html>



