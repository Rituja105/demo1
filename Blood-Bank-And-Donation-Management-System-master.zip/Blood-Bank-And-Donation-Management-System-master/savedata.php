

<?php
$name=$_POST['fullname'];
$number=$_POST['mobileno'];
$email=$_POST['emailid'];
$age=$_POST['age'];
$gender=$_POST['gender'];
$blood_group=$_POST['blood'];

$amt=$_POST['amt'];
$centre=$_POST['centre'];



$address=$_POST['address'];
$conn=mysqli_connect("localhost","root","","blood_donation") or die("Connection error");
$sql= "INSERT INTO donor_details(donor_name,donor_number,donor_mail,donor_age,donor_gender,donor_blood,donor_amt,donor_centre,donor_address) values('{$name}','{$number}','{$email}','{$age}','{$gender}','{$blood_group}','{$amt}','{$centre}','{$address}')";
$result=mysqli_query($conn,$sql) or die("query unsuccessful.");

header("Location: http://localhost/Blood-Bank-And-Donation-Management-System-master/succes.php");

mysqli_close($conn);
 ?>

