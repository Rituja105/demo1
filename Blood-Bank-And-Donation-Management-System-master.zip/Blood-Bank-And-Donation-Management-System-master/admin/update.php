<?php
	include('conn.php');
	$id=$_GET['id'];
 
	
    $ap=$_POST['ap'];
    $an=$_POST['an'];
    $bp=$_POST['bp'];
    $bn=$_POST['bn'];
    $abp=$_POST['abp'];
    $abn=$_POST['abn'];
    $op=$_POST['op'];
    $oz=$_POST['oz'];
    
	
 
	mysqli_query($conn,"update `avl` set ap='$ap',an='$an',bp='$bp',bn='$bn',abp='$abp',abn='$abn',op='$op',oz='$oz' where cenid='$id'");
	header('location:shri.php');
?>