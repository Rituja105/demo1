


<!DOCTYPE html>
<html>
<head>

<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>available</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">


</head>
<body>
	<div>
		<form method="POST" action="add.php">
			
	</div>
	<br>
	<div>

	<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  
	<div class="p-3 mb-2 bg-danger text-white"> <big> <b> <h2>Available Blood <h2> <b> <h5> Admin Panel <h5> <big> </div>

    <table class="table table-success table-striped">
  
    <thead>
    <tr>
      <th scope="col">Centre</th>
      <th scope="col">A+</th>
      <th scope="col">A-</th>
      <th scope="col">B+</th>
      <th scope="col">B-</th>
      <th scope="col">AB+</th>
      <th scope="col">AB-</th>
      <th scope="col">O+</th>
      <th scope="col">O-</th>
	  <th scope="col">Operations</th>
    </tr>
  </thead>
			<tbody>
				<?php
					include('conn.php');
					$result=mysqli_query($conn,"select * from `avl`");
					while($row=mysqli_fetch_array($result)){
						?>




						<tr>
							<td><?php echo $row['cen']; ?></td>
							<td><?php echo $row['ap']; ?></td>
							<td><?php echo $row['an']; ?></td>
							<td><?php echo $row['bp']; ?></td>
							<td><?php echo $row['bn']; ?></td>
							<td><?php echo $row['abp']; ?></td>
							<td><?php echo $row['abn']; ?></td>
							<td><?php echo $row['op']; ?></td>
							<td><?php echo $row['oz']; ?></td>
							<td>
								<a href="edit.php?id=<?php echo $row['cenid']; ?>">Edit</a>
								
							</td>
						</tr>
						<?php
					}
				?>

</tbody>
		</table>

		<div class="d-grid gap-2">
  <a class="btn btn-danger"  href="dashboard.php" role="button"><b>Back To Dashboard</b></a>
  
</div>
	</div>
</body>
</html>


