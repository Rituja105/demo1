


<?php
if(!empty($_POST['submit'])){
    $name = $_POST['name'];
    

// Add FPDF
require("fpdf/fpdf.php");

$pdf=new FPDF();
$pdf->AddPage();






// From INFORMATION



$pdf->Image('ctc.jpg',15,25,180,0,);
$pdf-> SetFont("Arial","B",25);
$pdf->Cell(0,130,"\n \n \n \n \n \n \n \n \n \n \n \n \n \n $name  ");



// for output

$pdf->output();
}


?>



