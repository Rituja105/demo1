<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>blood</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
  </head>
  <body>

  <?php
$active ='avail';
 include('head.php') ?>

  <div>
		<form method="POST" action="add.php">
			
	</div>
<hr>
  
<div class="p-3 mb-2 bg-danger text-white">  <b> <h2>Available Blood <h2> <b> <h5> Note: Here 1 Unit = 1 Blood Bag <h5>  </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  
<hr>

    <table class="table table-success table-striped">
  
    <thead>
    <tr>
      <th scope="col">Centre</th>
      <th scope="col">A+</th>
      <th scope="col">A-</th>
      <th scope="col">B+</th>
      <th scope="col">B-</th>
      <th scope="col">AB+</th>
      <th scope="col">AB-</th>
      <th scope="col">O+</th>
      <th scope="col">O-</th>
    </tr>
  </thead>
  <tbody>
  <?php
					include('conn.php');
					$result=mysqli_query($conn,"select * from `avl`");
					while($row=mysqli_fetch_array($result)){
						?>


<tr>
							<td><?php echo $row['cen']; ?></td>
							<td><?php echo $row['ap']; ?></td>
							<td><?php echo $row['an']; ?></td>
							<td><?php echo $row['bp']; ?></td>
							<td><?php echo $row['bn']; ?></td>
							<td><?php echo $row['abp']; ?></td>
							<td><?php echo $row['abn']; ?></td>
							<td><?php echo $row['op']; ?></td>
							<td><?php echo $row['oz']; ?></td>
							
						</tr>
						<?php
					}
                    ?>
  </tbody>

</table>


<div class="d-grid gap-2">
  <a class="btn btn-danger"  href="home.php" role="button"><b>Back To HomePage</b></a>
  
</div>
<?php include 'footer.php' ?>




</body>
</html>