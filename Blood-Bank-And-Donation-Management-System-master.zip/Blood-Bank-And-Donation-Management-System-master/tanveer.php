

<?php
$name=$_POST['fname'];
$number=$_POST['mno'];


$gender=$_POST['gen'];
$blood_group=$_POST['blood'];
$centre=$_POST['centre'];

$amt=$_POST['amt'];





$conn=mysqli_connect("localhost","root","","blood_donation") or die("Connection error");
$sql= "INSERT INTO `need_list`( `need_name`, `need_mno`, `need_gen`, `need_grp`, `need_cen`, `need_amt`) VALUES ('$name','$number','$gender','$blood_group','$centre','$amt')";
$result=mysqli_query($conn,$sql) or die("query unsuccessful.");


header("Location:http://localhost/Blood-Bank-And-Donation-Management-System-master/sddd.php");


mysqli_close($conn);
 ?>

